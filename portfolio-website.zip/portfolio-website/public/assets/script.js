


const viewWorkButton = document.getElementById("viewWorkButton");


viewWorkButton.addEventListener("click", () => {
   
    window.location.href = "/assets/my-work-page.html";
});